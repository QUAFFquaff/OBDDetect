from setuptools import setup, find_packages

setup(
    name='copkmeans',
    version='1.5',
    description='',
    author='',
    author_email='',
    url='https://github.com/Behrouz-Babaki/COP-Kmeans',
    license=license,
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False
)
