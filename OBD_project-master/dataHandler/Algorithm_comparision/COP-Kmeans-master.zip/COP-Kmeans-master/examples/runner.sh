#!/bin/bash
python ../copkmeans/run_ckm.py ./iris.data ./iris.constraints 5 
